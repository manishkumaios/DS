
struct Stack<T> {
    private var items: [T]?
    
    var isStackEmpty: Bool {
        items == nil
    }
    
    var top: T? {
        return items?.last
    }
    
   mutating func push(item: T) {
        guard !isStackEmpty else {
            items = []
            items?.append(item)
            return
        }
       items?.append(item)
    }
    
    mutating func pop() {
         guard !isStackEmpty else {
             print("Invalid operation - Stack is Empty")
             return
         }
        items?.removeLast()
     }
}

extension Stack: CustomStringConvertible {
    var description: String {
        return "---Stack --" + "\n" + (items?.map({String.init(describing: $0)})
            .reversed()
            .joined(separator: "\n") ?? "Empty Stack")
    }
}


var stackString = Stack<String>()
stackString.push(item: "One")
stackString.push(item: "Two")
stackString.push(item: "Three")

print("\n")
print("Top item is ---\(stackString.top ?? "Unavailble")")
print(stackString.description)
stackString.pop()
print("\n")
print(stackString.description)
    
var stackNumber = Stack<Int>()
stackNumber.push(item: 10)
stackNumber.push(item:3)
stackNumber.push(item: 5)

print("\n")
print("Top item is ---\(stackNumber.top ?? -1)")
print(stackNumber.description)
stackNumber.pop()
print("\n")
print(stackNumber.description)
